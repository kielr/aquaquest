__author__ = "kiel.regusters"
import sys
import os
import pygame as pg
from data import main

if __name__ == "__main__":
	main.main()
	pg.quit()
	sys.exit()
